<?php
if ($type != '') $type = '.'.$type;
require_once PH_THEME_PATH.'/layout/foot'.$type.'.tpl.php';
require_once PH_PATH.'/layout/foot.set.php';

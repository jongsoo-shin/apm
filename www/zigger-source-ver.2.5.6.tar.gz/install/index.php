<?php
require_once './install.core.php';
require_once './head.set.php';
require_once './html/index.html';
require_once './foot.set.php';

<?php
use Corelib\Func;

require_once '../lib/ph.core.php';

Func::location(PH_DIR.'/manage/main/dash');

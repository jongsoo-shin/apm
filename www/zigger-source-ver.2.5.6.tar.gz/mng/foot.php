<?php
require_once PH_MANAGE_PATH.'/html/foot.tpl.php';
require_once PH_MANAGE_PATH.'/foot.set.php';
